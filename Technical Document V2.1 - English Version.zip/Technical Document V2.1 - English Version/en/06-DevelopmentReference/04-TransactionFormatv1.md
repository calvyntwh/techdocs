# Transaction Format v1

Transaction format version V1 is no longer directly supported since BCBChain v2.0. The program only supports the call of old contracts of BCBChain v1.0.
